package com.stsl.myloginregistrationtutorials.FragmentPackages;



import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.stsl.myloginregistrationtutorials.MainActivity;
import com.stsl.myloginregistrationtutorials.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class LandingScreenFragment extends Fragment {
    TextView LogoText, LogoSlogan, SignupText, SignupDesc, LoginWithEmailPassword;
    Button SignupWithEmailPassword;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_landing_screen, container, false);

        InitViews(view);

        return view;

    }

    //initializing views
    private void InitViews(View view) {
        LogoText = view.findViewById(R.id.logo_text);
        LogoSlogan = view.findViewById(R.id.logo_slogan);
        SignupText = view.findViewById(R.id.signup_text);
        SignupDesc = view.findViewById(R.id.signup_desc);

        LoginWithEmailPassword = view.findViewById(R.id.login_with_email_password);
        SignupWithEmailPassword = view.findViewById(R.id.signup_with_email_psswrod);

        //method to fire up click event
        FireUpEvents();

        //Apply typeface to textviews
        SetTextViewsTypeface();


    }

    private void SetTextViewsTypeface() {
        ChangeTypeFace(LogoText, "fonts/impact.ttf");
        ChangeTypeFace(LogoSlogan, "fonts/Roboto-Thin.ttf");
        ChangeTypeFace(SignupText, "fonts/segoeui.ttf");
        ChangeTypeFace(SignupDesc, "fonts/RAGE.TTF");
    }

    private void FireUpEvents() {

        SignupWithEmailPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = MainActivity.fragmentManager.beginTransaction();
                RegisterScreenFragment RSF = new RegisterScreenFragment();
                ft.replace(R.id.host_layout, RSF).addToBackStack("Home");
                ft.commit();
            }
        });

        LoginWithEmailPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = MainActivity.fragmentManager.beginTransaction();
                LoginScreenFragment LSF = new LoginScreenFragment();
                ft.replace(R.id.host_layout, LSF).addToBackStack("Home");
                ft.commit();
            }
        });
    }


    //Method to change typeface
    private void ChangeTypeFace(TextView textView, String Font){
        Typeface typeface = Typeface.createFromAsset(getContext().getAssets(), Font);
        textView.setTypeface(typeface);
    }


}
