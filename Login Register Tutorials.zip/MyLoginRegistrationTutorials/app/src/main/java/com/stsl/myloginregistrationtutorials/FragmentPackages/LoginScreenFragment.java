package com.stsl.myloginregistrationtutorials.FragmentPackages;


import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.fragment.app.Fragment;

import com.stsl.myloginregistrationtutorials.R;
import com.stsl.myloginregistrationtutorials.WelcomeScreen;

/**
 * A simple {@link Fragment} subclass.
 */
public class LoginScreenFragment extends Fragment {

    EditText Username, Password;
    Button Login;

    public LoginScreenFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_login_screen, container, false);
        //instance of init method
        InitViews(view);
        return view;
    }

    private void InitViews(View view) {
        Username = view.findViewById(R.id.login_username);
        Password = view.findViewById(R.id.login_password);
        Login = view.findViewById(R.id.login_btn);

        //instance of view validation
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MakeLogin();
            }
        });

    }

    //Login Method
    private void MakeLogin() {
        String username, chossepassword, confirmpassword;
        username = Username.getText().toString().trim();
        chossepassword = Password.getText().toString().trim();

        //validate views before registering the user
        if (TextUtils.isEmpty(username)) {
            Username.setError("Please Enter your name");
            Username.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(chossepassword)) {
            Password.setError("Please Choose password");
            Password.requestFocus();
            return;
        }

        Intent welcome = new Intent(getContext(), WelcomeScreen.class);
        welcome.putExtra("name", username);
        startActivity(welcome);
        //getActivity().finish();
    }

    public static void fireup(View view){

    }

}
