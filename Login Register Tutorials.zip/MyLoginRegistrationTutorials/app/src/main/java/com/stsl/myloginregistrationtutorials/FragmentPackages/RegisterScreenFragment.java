package com.stsl.myloginregistrationtutorials.FragmentPackages;


import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.stsl.myloginregistrationtutorials.R;
import com.stsl.myloginregistrationtutorials.WelcomeScreen;

/**
 * A simple {@link Fragment} subclass.
 */
public class RegisterScreenFragment extends Fragment {

    TextView BackPressed, SendtoLogin;
    EditText Username, ChoosePassword, ConfirmPassword;
    Button RegisterBtn;


    public RegisterScreenFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_register_screen, container, false);

        //instance to init Views;
        InitViews(view);

        return view;
    }

    private void InitViews(View view) {
        BackPressed = view.findViewById(R.id.textiew_backpressed);
        Username = view.findViewById(R.id.user_name);
        ChoosePassword = view.findViewById(R.id.choose_password);
        ConfirmPassword = view.findViewById(R.id.confirm_password);
        RegisterBtn = view.findViewById(R.id.register_btn);
        SendtoLogin = view.findViewById(R.id.send_to_loginscreen);

        //instance to fire up event
        RegisterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MakeRegistration();
            }
        });

    }

    private void MakeRegistration() {
        String username, chossepassword, confirmpassword;
        username = Username.getText().toString().trim();
        chossepassword = ChoosePassword.getText().toString().trim();
        confirmpassword = ConfirmPassword.getText().toString().trim();

        //validate views before registering the user
        if (TextUtils.isEmpty(username)) {
            Username.setError("Please Enter your name");
            Username.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(chossepassword)) {
            ChoosePassword.setError("Please Choose password");
            ChoosePassword.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(confirmpassword)) {
            ConfirmPassword.setError("Please Enter your name");
            ConfirmPassword.requestFocus();
            return;
        }

        if (chossepassword.length() < 6) {
            ChoosePassword.setError("Please password should be 6 characters and above");
            ChoosePassword.requestFocus();
            return;
        }

        if (!confirmpassword.equals(chossepassword)) {
            ConfirmPassword.setError("Please the input password does not match");
            return;
        }

        Intent welcome = new Intent(getContext(), WelcomeScreen.class);
        welcome.putExtra("name", username);
        startActivity(welcome);
        //getActivity().finish();
    }

    public static void fireup(View view){

    }

}
