package com.stsl.myloginregistrationtutorials;


import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.stsl.myloginregistrationtutorials.FragmentPackages.LandingScreenFragment;
import com.stsl.myloginregistrationtutorials.FragmentPackages.LoginScreenFragment;
import com.stsl.myloginregistrationtutorials.FragmentPackages.RegisterScreenFragment;


public class MainActivity extends AppCompatActivity {
    public static FragmentManager fragmentManager;
    FrameLayout frameLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        frameLayout = findViewById(R.id.host_layout);
        fragmentManager = getSupportFragmentManager();

        InitFragments(savedInstanceState);
    }

    private void InitFragments(Bundle savedInstanceState) {
        if (findViewById(R.id.host_layout) != null) {
            if (savedInstanceState != null) {
                return;
            }
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            LandingScreenFragment landingScreenFragment = new LandingScreenFragment();
            fragmentTransaction.add(R.id.host_layout, landingScreenFragment, null);
            fragmentTransaction.commit();
        }
    }

    public void fireup(View view) {
        RegisterScreenFragment.fireup(view);
        switch (view.getId()) {
            case R.id.textiew_backpressed:
                onBackPressed();
                break;
            case R.id.send_to_loginscreen:
                FragmentTransaction ft = fragmentManager.beginTransaction();
                LoginScreenFragment LSF = new LoginScreenFragment();
                ft.replace(R.id.host_layout, LSF);
                ft.commit();
                break;

            case R.id.lback:
                onBackPressed();
                break;
            case R.id.sendtoregiser:
                FragmentTransaction ftn = fragmentManager.beginTransaction();
                RegisterScreenFragment RSF = new RegisterScreenFragment();
                ftn.replace(R.id.host_layout, RSF);
                ftn.commit();
                break;

        }
    }
}
