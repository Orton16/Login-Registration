package com.stsl.myloginregistrationtutorials;


import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomeScreen extends AppCompatActivity {
    TextView Welcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_screen);

        Welcome = findViewById(R.id.welcom_text);

        String name = getIntent().getStringExtra("name");
        Welcome.setText("WELCOME " + name);
    }
}
